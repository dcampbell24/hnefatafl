﻿$ErrorActionPreference = 'Stop'
Start-ChocolateyProcessAsAdmin "$($env:LocalAppData)\hnefatafl-copenhagen\Uninstall.exe"
