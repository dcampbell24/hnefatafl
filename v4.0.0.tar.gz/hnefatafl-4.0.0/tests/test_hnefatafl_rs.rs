use hnefatafl_copenhagen::hnefatafl_rs;

#[test]
fn test_hnefatafl_rs() -> anyhow::Result<()> {
    hnefatafl_rs()
}
