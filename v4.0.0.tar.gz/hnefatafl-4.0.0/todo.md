# Todo

## Main

1. Get `brew install --cask hnefatafl-copenhagen` working (macOS).
2. Get SSL working.
3. Rate limiting?

## Add Hoc
