# Contribute

All contributions are welcome. If you are going to make a non-trivial change,
open an [issue] first to discuss your idea.

[issue]: https://github.com/dcampbell24/hnefatafl-copenhagen/issues
